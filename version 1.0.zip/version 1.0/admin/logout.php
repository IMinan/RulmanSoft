<?php include('_inc/header.php'); ?>
	<?php session_unset(); ?>
	<?php header("Location: ".site_url('')); ?>
<?php include('_inc/footer.php'); ?>
