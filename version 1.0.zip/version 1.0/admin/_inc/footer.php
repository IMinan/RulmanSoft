<div class="h50 hidden-xs hidden-sm"></div>
</div> <!-- /.container [header.php]-->
<footer>
	<div class="footer-bottom">
		<div class="container">
			<div class="pull-right">© Alt yapı <a href="http://rulmansoft.com" title="RulmanSoft" target="_blank" style="text-decoration:underline;">RulmanSoft.com</a> ekibi tarafından yazılmıştır.</div>
		</div> <!-- /.container -->
	</div> <!-- /.footer-bottom -->
</footer>

</body>
</html>
