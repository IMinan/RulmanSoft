-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Anamakine: localhost
-- Üretim Zamanı: 12 Nis 2016, 16:08:54
-- Sunucu sürümü: 10.1.10-MariaDB
-- PHP Sürümü: 7.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;

--
-- Veritabanı: `rulmansoft`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `list`
--

CREATE TABLE `list` (
  `id` int(11) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `date` datetime NOT NULL,
  `microtime` varchar(25) NOT NULL,
  `user_id` int(11) NOT NULL,
  `code` varchar(20) NOT NULL,
  `code_type` varchar(20) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `description` varchar(200) NOT NULL,
  `price` decimal(10,4) NOT NULL,
  `currency` int(1) NOT NULL,
  `guid` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `list_meta`
--

CREATE TABLE `list_meta` (
  `id` int(11) NOT NULL,
  `list_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `_key` varchar(20) NOT NULL,
  `val_1` varchar(500) NOT NULL,
  `val_2` varchar(500) NOT NULL,
  `val_3` varchar(500) NOT NULL,
  `val_int` int(11) NOT NULL,
  `val_decimal` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `list_stock`
--

CREATE TABLE `list_stock` (
  `id` int(11) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `date` datetime NOT NULL,
  `microtime` varchar(25) NOT NULL,
  `user_id` int(11) NOT NULL,
  `list_id` int(11) NOT NULL,
  `in_out` int(1) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `message`
--

CREATE TABLE `message` (
  `id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `microtime` varchar(25) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `top_id` int(11) NOT NULL,
  `out_user_id` int(11) NOT NULL,
  `in_user_id` int(11) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `reading` int(1) NOT NULL DEFAULT '0',
  `reading_date` datetime NOT NULL,
  `ip` varchar(15) NOT NULL,
  `name_surname` varchar(30) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `date` datetime NOT NULL,
  `update_date` datetime NOT NULL,
  `title` varchar(255) NOT NULL,
  `list_img` varchar(255) NOT NULL,
  `content` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `options`
--

CREATE TABLE `options` (
  `id` int(11) NOT NULL,
  `meta_key` varchar(50) NOT NULL,
  `val_1` varchar(500) NOT NULL,
  `val_2` varchar(255) NOT NULL,
  `val_3` text NOT NULL,
  `val_int` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL,
  `date_update` datetime NOT NULL,
  `microtime` varchar(25) NOT NULL,
  `company_id` int(20) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `name` varchar(20) NOT NULL,
  `surname` varchar(20) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `address` varchar(500) NOT NULL,
  `district` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `country` varchar(20) NOT NULL,
  `product_brand` varchar(20) NOT NULL,
  `product_code` varchar(20) NOT NULL,
  `code_type` varchar(20) NOT NULL,
  `product_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `sale_price` decimal(10,2) NOT NULL,
  `currency` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `pages`
--

CREATE TABLE `pages` (
  `id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `date` datetime NOT NULL,
  `update_date` datetime NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `url` varchar(1000) NOT NULL,
  `m_short` int(3) NOT NULL,
  `m_title` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `date` datetime NOT NULL,
  `brand_id` int(11) NOT NULL,
  `code` varchar(20) NOT NULL,
  `code_type` varchar(20) NOT NULL,
  `d0` int(11) NOT NULL,
  `D` int(11) NOT NULL,
  `B` int(11) NOT NULL,
  `mass` varchar(10) NOT NULL,
  `reference_speed` int(11) NOT NULL,
  `limiting_speed` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `product_brand`
--

CREATE TABLE `product_brand` (
  `id` int(11) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `alignment` int(3) NOT NULL DEFAULT '999',
  `name` varchar(20) NOT NULL,
  `description` text NOT NULL,
  `logo` varchar(255) NOT NULL,
  `count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `product_brand`
--

INSERT INTO `product_brand` (`id`, `status`, `alignment`, `name`, `description`, `logo`, `count`) VALUES
(1, 1, 0, 'SKF', 'SKF, 1907''den beri lider bir global teknoloji sağlayıcısı olmuştur. Esas gücümüz sürekli olarak yeni teknolojiler geliştirebilme yeteneğimiz ve bunları müşterilerimize rakiplerine karşı avantaj sağlayan ürünler oluşturmak için kullanmamızdır. Bu başarıyı, SKF teknoloji platformlarındaki bilgimizle 40''tan fazla sektöre ilişkin pratik deneyimi birleştirme yoluyla elde ediyoruz: Rulmanlar ve üniteler, mekatronik, servis hizmetleri ve yağlama sistemleri. Başarımız bu bilgiye, çalışanlarımıza ve SKF Hizmetleri ilkelerine bağlılığımıza dayanmaktadır. ', 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b8/SKF_logo.svg/370px-SKF_logo.svg.png', 1),
(2, 1, 0, 'FAG', '', '', 464),
(3, 1, 0, 'URB', '', '', 67),
(4, 1, 0, 'ORS', '', '', 24),
(5, 1, 999, 'RMZ', '', '', 0),
(6, 1, 999, 'INR', '', '', 0),
(7, 1, 999, 'IRS', '', '', 0),
(8, 1, 999, 'BARDEN', '', '', 2),
(9, 1, 999, 'BECO', '', '', 0),
(10, 1, 999, 'BCA', '', '', 0),
(11, 1, 999, 'BCHH', '', '', 0),
(12, 1, 999, 'BOWER', '', '', 0),
(13, 1, 999, 'CHINA', '', '', 0),
(14, 1, 999, 'CKJ', '', '', 1),
(15, 1, 999, 'CNR', '', '', 0),
(16, 1, 999, 'DKF', '', '', 31),
(17, 1, 999, 'DURKOPP', '', '', 0),
(19, 1, 0, 'INA', '', '', 12),
(20, 1, 999, 'GPZ', '', '', 23),
(21, 1, 999, 'IKO', '', '', 0),
(22, 1, 999, 'KOYO', '', '', 24),
(23, 1, 999, 'NSK', '', '', 95),
(24, 1, 999, 'NTN', '', '', 39),
(25, 1, 999, 'RHP', '', '', 27),
(26, 1, 999, 'RIV', '', '', 9),
(27, 1, 999, 'SNR', '', '', 18),
(28, 1, 999, 'STEYR', '', '', 26),
(29, 1, 999, 'TIMKEN', '', '', 36),
(31, 1, 999, 'ZKL', '', '', 58),
(32, 1, 999, 'KWC', '', '', 0);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `date` datetime NOT NULL,
  `user_type` varchar(20) NOT NULL DEFAULT 'user',
  `email` varchar(100) NOT NULL,
  `gsm` varchar(20) NOT NULL,
  `password` varchar(32) NOT NULL,
  `name` varchar(20) NOT NULL,
  `surname` varchar(20) NOT NULL,
  `company_name` varchar(50) NOT NULL,
  `city` varchar(20) NOT NULL,
  `district` varchar(20) NOT NULL,
  `country` varchar(20) NOT NULL,
  `address` varchar(500) NOT NULL,
  `guid` varchar(100) NOT NULL,
  `balance` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `users`
--

INSERT INTO `users` (`id`, `status`, `date`, `user_type`, `email`, `gsm`, `password`, `name`, `surname`, `company_name`, `city`, `district`, `country`, `address`, `guid`, `balance`) VALUES
(75, 1, '2015-12-11 00:10:14', 'corporate', 'info@rulmansoft.com', '5322342323', 't123456', 'Muhammet', 'İnan', 'Rulmansoft', 'İstanbul', 'İkitelli', '', '', '75-RulmanSoft', '0.00'),
(79, 1, '2016-03-31 12:01:48', 'user', 'info@account.com', '5340149563', 't123456', 'Account', 'Account', 'Account', 'Account', 'Account', 'Account', 'AccountAccountAccountAccountAccount', '79-account', '0.00');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `_log`
--

CREATE TABLE `_log` (
  `id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `microtime` varchar(25) COLLATE utf8_turkish_ci NOT NULL,
  `ip` varchar(15) COLLATE utf8_turkish_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(20) COLLATE utf8_turkish_ci NOT NULL,
  `description` varchar(100) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `_log`
--

INSERT INTO `_log` (`id`, `date`, `microtime`, `ip`, `user_id`, `type`, `description`) VALUES
(52, '2015-12-11 02:19:10', '0.09390100 1449796739', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(53, '2015-12-12 11:25:25', '0.87764500 1449915905', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(54, '2015-12-14 19:02:19', '0.54935200 1450116129', '::1', 0, 'login_error', 'info@tanriverdirulman.com uye girisi basarisiz.'),
(55, '2015-12-14 19:02:28', '0.43631000 1450116139', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(56, '2016-01-07 14:59:39', '0.30169800 1452175167', '::1', 0, 'login_error', 'info@tanriverdirulman.com uye girisi basarisiz.'),
(57, '2016-01-07 15:00:02', '0.26451000 1452175179', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(58, '2016-01-18 14:11:08', '0.69801500 1453122664', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(59, '2016-01-18 14:14:26', '0.71242900 1453122859', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(60, '2016-01-18 15:39:03', '0.15912800 1453127937', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(61, '2016-01-20 17:06:55', '0.20002600 1453305999', '192.168.1.33', 75, 'login_success', 'Giriş yapıldı.'),
(62, '2016-01-21 13:05:12', '0.53228900 1453377862', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(63, '2016-01-21 14:33:52', '0.20851300 1453383225', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(64, '2016-01-21 14:59:10', '0.70897400 1453384735', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(65, '2016-01-21 16:49:52', '0.88114500 1453391389', '::1', 0, 'login_error', 'whoiam uye girisi basarisiz.'),
(66, '2016-01-21 16:50:01', '0.17758100 1453391392', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(67, '2016-01-21 16:51:13', '0.04838200 1453391434', '::1', 0, 'login_error', 'info@tanriverdirulman.com uye girisi basarisiz.'),
(68, '2016-01-21 16:51:25', '0.20215500 1453391473', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(69, '2016-01-21 16:52:04', '0.35415400 1453391508', '::1', 0, 'login_error', 'info@tanriverdi.com uye girisi basarisiz.'),
(70, '2016-01-21 16:52:17', '0.13068700 1453391524', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(71, '2016-01-21 17:41:40', '0.07834800 1453394494', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(72, '2016-01-25 12:12:09', '0.40983300 1453720305', '::1', 0, 'login_error', 'info@thetanriverdi.com uye girisi basarisiz.'),
(73, '2016-01-25 12:12:26', '0.18178400 1453720329', '::1', 0, 'login_error', 'info@tanriverdirulman.com uye girisi basarisiz.'),
(74, '2016-01-25 12:13:16', '0.30641300 1453720346', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(75, '2016-01-25 15:14:17', '0.69969300 1453731239', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(76, '2016-01-26 11:58:25', '0.21943600 1453805881', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(77, '2016-01-26 16:12:35', '0.57147800 1453821131', '::1', 0, 'login_error', 'info@rulmansoft.php uye girisi basarisiz.'),
(78, '2016-01-26 16:12:48', '0.25249300 1453821155', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(79, '2016-01-28 10:45:05', '0.06329200 1453974289', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(80, '2016-01-28 16:57:47', '0.13841500 1453996656', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(81, '2016-01-28 17:01:45', '0.64776800 1453996892', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(82, '2016-02-02 13:01:17', '0.24330600 1454414459', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(83, '2016-03-19 11:46:15', '0.05864200 1458384364', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(84, '2016-03-21 13:24:12', '0.00535100 1458563044', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(85, '2016-03-21 20:57:44', '0.03304500 1458590253', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(86, '2016-03-23 10:07:04', '0.61293400 1458724006', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(87, '2016-03-28 08:11:29', '0.95275200 1459145478', '::1', 0, 'login_error', 'info@rulmansoft.com uye girisi basarisiz.'),
(88, '2016-03-28 08:11:42', '0.77291700 1459145489', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(89, '2016-03-28 10:14:24', '0.64929600 1459152848', '::1', 0, 'login_error', 'info@rulmansoft.com uye girisi basarisiz.'),
(90, '2016-03-28 10:14:35', '0.92851900 1459152864', '::1', 0, 'login_error', 'info@rulmansoft.com uye girisi basarisiz.'),
(91, '2016-03-28 10:14:45', '0.15687300 1459152875', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(92, '2016-03-28 10:53:57', '0.58973800 1459155226', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(93, '2016-03-28 18:59:30', '', '::1', 75, 'login_error', ' uye girisi basarisiz.'),
(103, '2016-03-29 11:33:20', '0.28692700 1459243987', '::1', 0, 'login_error', 'info@rulmansoft.com uye girisi basarisiz.'),
(104, '2016-03-29 12:02:41', '0.57502600 1459245725', '::1', 25, 'account_login_succes', 'Giriş yapıldı.'),
(105, '2016-03-29 13:29:24', '0.31575900 1459250948', '::1', 0, 'login_error', 'sifre@sifre.com uye girisi basarisiz.'),
(106, '2016-03-29 13:29:33', '0.74539900 1459250964', '::1', 25, 'account_login_succes', 'Giriş yapıldı.'),
(107, '2016-03-29 14:19:13', '0.86796700 1459253937', '::1', 25, 'account_login_succes', 'Giriş yapıldı.'),
(108, '2016-03-29 15:10:48', '0.61453300 1459257036', '::1', 0, 'login_error', 'account@account.com uye girisi basarisiz.'),
(109, '2016-03-29 15:11:01', '0.87781500 1459257048', '::1', 25, 'account_login_succes', 'Giriş yapıldı.'),
(110, '2016-03-29 15:41:12', '0.22900500 1459258858', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(111, '2016-03-29 16:11:55', '0.84874000 1459260703', '::1', 0, 'login_error', 'info@account.com uye girisi basarisiz.'),
(112, '2016-03-29 16:12:04', '0.05922400 1459260715', '::1', 25, 'account_login_succes', 'Giriş yapıldı.'),
(113, '2016-03-29 16:21:21', '0.05898800 1459261263', '::1', 0, 'login_error', 'info@account.com uye girisi basarisiz.'),
(114, '2016-03-29 16:21:33', '0.83619700 1459261281', '::1', 0, 'login_error', 'info@account.com uye girisi basarisiz.'),
(115, '2016-03-29 16:22:30', '0.66016700 1459261293', '::1', 0, 'login_error', 'info@accounts.com uye girisi basarisiz.'),
(116, '2016-03-29 16:22:56', '0.39301600 1459261350', '::1', 0, 'login_error', 'info@accounts.com uye girisi basarisiz.'),
(117, '2016-03-29 16:23:06', '0.01267000 1459261376', '::1', 25, 'account_login_succes', 'Giriş yapıldı.'),
(118, '2016-03-29 16:49:57', '0.84985900 1459262986', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(119, '2016-03-29 17:11:30', '0.91819200 1459264279', '::1', 0, 'login_error', 'info@accounts.com uye girisi basarisiz.'),
(120, '2016-03-29 17:11:42', '0.47453600 1459264290', '::1', 25, 'account_login_succes', 'Giriş yapıldı.'),
(121, '2016-03-31 09:42:14', '0.18199600 1459410126', '::1', 75, 'login_error', 'info@account.com uye girisi basarisiz.'),
(122, '2016-03-31 09:42:23', '0.53585200 1459410134', '::1', 25, 'account_login_succes', 'Giriş yapıldı.'),
(123, '2016-03-31 14:21:03', '0.95497900 1459426850', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(124, '2016-03-31 14:29:52', '0.72837500 1459427384', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(125, '2016-03-31 14:35:26', '0.36958700 1459427664', '::1', 79, 'login_success', 'Giriş yapıldı.'),
(126, '2016-03-31 14:36:21', '0.45037200 1459427770', '::1', 79, 'login_success', 'Giriş yapıldı.'),
(127, '2016-03-31 14:52:07', '0.52891300 1459428718', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(128, '2016-03-31 14:52:27', '0.80094700 1459428737', '::1', 0, 'login_error', 'info@accounts.com uye girisi basarisiz.'),
(129, '2016-03-31 14:52:34', '0.64833300 1459428747', '::1', 79, 'login_success', 'Giriş yapıldı.'),
(130, '2016-03-31 15:30:24', '0.77195200 1459431009', '::1', 79, 'login_success', 'Giriş yapıldı.'),
(131, '2016-03-31 15:34:07', '0.73111500 1459431238', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(132, '2016-03-31 18:53:46', '0.00296000 1459443212', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(133, '2016-04-01 12:20:36', '0.75647400 1459506025', '::1', 79, 'login_success', 'Giriş yapıldı.'),
(134, '2016-04-01 12:22:06', '0.13972300 1459506115', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(135, '2016-04-01 12:22:32', '0.85868600 1459506142', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(136, '2016-04-01 12:22:47', '0.60078400 1459506160', '::1', 79, 'login_success', 'Giriş yapıldı.'),
(137, '2016-04-01 12:44:06', '0.29970700 1459507435', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(138, '2016-04-04 10:33:13', '0.04769100 1459758785', '::1', 79, 'login_success', 'Giriş yapıldı.'),
(139, '2016-04-04 10:41:17', '0.75088700 1459759266', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(140, '2016-04-04 11:10:52', '0.23397100 1459761044', '::1', 79, 'login_success', 'Giriş yapıldı.'),
(141, '2016-04-04 11:56:31', '0.60098700 1459763783', '::1', 79, 'login_success', 'Giriş yapıldı.'),
(142, '2016-04-04 12:47:06', '0.44200200 1459766817', '::1', 0, 'login_error', 'info@account.com uye girisi basarisiz.'),
(143, '2016-04-04 12:47:16', '0.32981900 1459766826', '::1', 79, 'login_success', 'Giriş yapıldı.'),
(144, '2016-04-04 12:57:42', '0.65996500 1459767439', '::1', 79, 'login_success', 'Giriş yapıldı.'),
(145, '2016-04-04 14:36:12', '0.91052000 1459773349', '::1', 80, 'login_success', 'Giriş yapıldı.'),
(146, '2016-04-04 14:36:44', '0.12707900 1459773307', '::1', 80, 'login_success', 'Giriş yapıldı.'),
(147, '2016-04-04 14:59:14', '0.39649100 1459774739', '::1', 80, 'login_success', 'Giriş yapıldı.'),
(148, '2016-04-04 15:31:25', '0.26479300 1459776670', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(149, '2016-04-04 15:31:52', '0.25256900 1459776704', '::1', 79, 'login_success', 'Giriş yapıldı.'),
(150, '2016-04-05 15:50:48', '0.62178200 1459864239', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(151, '2016-04-05 15:53:25', '0.82798200 1459864397', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(152, '2016-04-05 15:53:47', '0.20228100 1459864410', '::1', 80, 'login_success', 'Giriş yapıldı.'),
(153, '2016-04-05 16:39:03', '0.58594900 1459867132', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(154, '2016-04-05 16:45:01', '0.31432900 1459867487', '::1', 0, 'login_error', 'muhammet11990@gmail.com uye girisi basarisiz.'),
(155, '2016-04-05 16:45:15', '0.88302900 1459867501', '::1', 80, 'login_success', 'Giriş yapıldı.'),
(156, '2016-04-05 17:13:31', '0.12513600 1459869193', '::1', 80, 'login_success', 'Giriş yapıldı.'),
(157, '2016-04-05 17:32:11', '0.62030600 1459870323', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(158, '2016-04-05 21:35:17', '0.92960000 1459884902', '::1', 80, 'login_success', 'Giriş yapıldı.'),
(159, '2016-04-05 21:35:32', '0.10505300 1459884923', '::1', 0, 'login_error', 'info@rulmansoft.com uye girisi basarisiz.'),
(160, '2016-04-05 21:35:43', '0.11824800 1459884932', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(161, '2016-04-06 09:15:02', '0.96283200 1459926889', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(162, '2016-04-06 09:46:04', '0.63296200 1459928727', '192.168.1.45', 80, 'login_success', 'Giriş yapıldı.'),
(163, '2016-04-06 11:22:00', '0.88404600 1459934512', '::1', 0, 'login_error', 'info@rulmansoft.com uye girisi basarisiz.'),
(164, '2016-04-06 11:22:14', '0.28166800 1459934520', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(165, '2016-04-06 11:22:33', '0.78387800 1459934539', '::1', 0, 'login_error', 'muhammet11990@gmail.com uye girisi basarisiz.'),
(166, '2016-04-06 11:22:44', '0.63848200 1459934553', '::1', 80, 'login_success', 'Giriş yapıldı.'),
(167, '2016-04-06 15:37:15', '0.42890300 1459949822', '::1', 80, 'login_success', 'Giriş yapıldı.'),
(168, '2016-04-06 15:39:08', '0.16183800 1459949944', '::1', 0, 'login_error', 'muhammet11990@gmail.com uye girisi basarisiz.'),
(169, '2016-04-06 15:40:07', '0.26865600 1459950004', '::1', 0, 'login_error', 'muhammet11990@gmail.com uye girisi basarisiz.'),
(182, '2016-04-06 16:05:27', '0.56982500 1459951511', '::1', 80, 'login_success', 'Giriş yapıldı.'),
(183, '2016-04-06 16:56:31', '0.17009900 1459954583', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(184, '2016-04-07 11:23:48', '0.28871900 1460021014', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(185, '2016-04-07 14:26:11', '0.24524600 1460031965', '::1', 80, 'login_success', 'Giriş yapıldı.'),
(186, '2016-04-07 14:28:27', '0.13778400 1460032104', '::1', 0, 'login_error', 'muhammet11990@gmail.com uye girisi basarisiz.'),
(187, '2016-04-07 14:29:03', '0.12028600 1460032140', '::1', 80, 'login_success', 'Giriş yapıldı.'),
(188, '2016-04-11 09:38:13', '0.78362900 1460360280', '::1', 75, 'login_success', 'Giriş yapıldı.'),
(189, '2016-04-11 10:20:01', '0.36113100 1460362780', '::1', 75, 'login_success', 'Giriş yapıldı.');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `list`
--
ALTER TABLE `list`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `microtime` (`microtime`);

--
-- Tablo için indeksler `list_meta`
--
ALTER TABLE `list_meta`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `list_stock`
--
ALTER TABLE `list_stock`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `microtime` (`microtime`);

--
-- Tablo için indeksler `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `microtime` (`microtime`);

--
-- Tablo için indeksler `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Tablo için indeksler `product_brand`
--
ALTER TABLE `product_brand`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Tablo için indeksler `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `_log`
--
ALTER TABLE `_log`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `microtime` (`microtime`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `list`
--
ALTER TABLE `list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `list_meta`
--
ALTER TABLE `list_meta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `list_stock`
--
ALTER TABLE `list_stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `message`
--
ALTER TABLE `message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `options`
--
ALTER TABLE `options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `product_brand`
--
ALTER TABLE `product_brand`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- Tablo için AUTO_INCREMENT değeri `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;
--
-- Tablo için AUTO_INCREMENT değeri `_log`
--
ALTER TABLE `_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=190;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
