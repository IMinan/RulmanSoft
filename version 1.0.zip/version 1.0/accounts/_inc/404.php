<div class="height head-jumbotron padding-20">
	<h2>Aradığınız Sayfa Bulunamadı</h2>
	<p><a href="index.php">Anasayfa</a>'ya Dönebilir</p>
	<p>Detaylı bilgi için Firma ile İletişime Geçebilirsiniz.</p>
	<p>Arama Formunu Kullanarak Aradığınız ürünü Kolaylıkla bulabilirsiniz.</p>
</div>
