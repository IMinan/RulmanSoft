<?php include('_inc/header.php'); ?>
	<?php session_unset(); ?>
	<?php header("Location: ".account_url('')); ?>
<?php include('_inc/footer.php'); ?>
